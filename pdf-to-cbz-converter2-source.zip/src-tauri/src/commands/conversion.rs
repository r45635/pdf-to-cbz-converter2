use crate::utils;
use std::fs;
use std::path::PathBuf;
use rayon::prelude::*;
use tauri::Emitter;
use std::sync::{Arc, atomic::{AtomicUsize, Ordering}};

#[tauri::command]
pub async fn convert_pdf_to_cbz(
    window: tauri::Window,
    path: String,
    dpi: u32,
    quality: u32,
    lossless: bool,
) -> Result<Vec<u8>, String> {
    use std::time::Instant;
    let start_time = Instant::now();
    
    eprintln!("[GUI {:?}] ========== CONVERSION START ==========", start_time.elapsed());
    eprintln!("[GUI {:?}] Input path: {}", start_time.elapsed(), path);
    eprintln!("[GUI {:?}] DPI: {}, Quality: {}, Lossless: {}", start_time.elapsed(), dpi, quality, lossless);
    
    if !PathBuf::from(&path).exists() {
        eprintln!("[GUI ERROR {:?}] PDF file not found: {}", start_time.elapsed(), path);
        return Err("PDF file not found".to_string());
    }
    eprintln!("[GUI {:?}] File exists, checking size...", start_time.elapsed());

    let effective_dpi = if dpi == 0 { 200 } else { dpi };
    let effective_quality = if quality == 0 { 85 } else { quality };

    eprintln!("[GUI {:?}] Effective DPI: {}, Effective Quality: {}", start_time.elapsed(), effective_dpi, effective_quality);

    // Read PDF file
    eprintln!("[GUI {:?}] Reading PDF file...", start_time.elapsed());
    let pdf_data = fs::read(&path)
        .map_err(|e| {
            let err_msg = format!("Failed to read PDF file: {}", e);
            eprintln!("[GUI ERROR {:?}] {}", start_time.elapsed(), err_msg);
            err_msg
        })?;
    
    eprintln!("[GUI {:?}] PDF file read successfully: {} bytes", start_time.elapsed(), pdf_data.len());
    
    let _ = window.emit("conversion-progress", serde_json::json!({
        "percentage": 5,
        "message": "PDF chargé, démarrage conversion..."
    }));

    // Convert using parallel processing
    eprintln!("[GUI {:?}] Starting conversion task...", start_time.elapsed());
    
    let window_clone = window.clone();
    let images = tokio::task::spawn_blocking(move || {
        let block_start = Instant::now();
        eprintln!("[GUI {:?}] Inside blocking task, starting conversion...", block_start.elapsed());
        let result = if lossless {
            eprintln!("[GUI {:?}] Using lossless mode (PNG at {} DPI)", block_start.elapsed(), effective_dpi);
            convert_pdf_lossless(&pdf_data, effective_dpi)
        } else {
            eprintln!("[GUI {:?}] Using parallel mode with DPI={}, Quality={}", block_start.elapsed(), effective_dpi, effective_quality);
            convert_pdf_with_pdfium_parallel(&pdf_data, effective_dpi, effective_quality as u8, window_clone)
        };
        
        match &result {
            Ok(imgs) => eprintln!("[GUI {:?}] Conversion succeeded: {} images", block_start.elapsed(), imgs.len()),
            Err(e) => eprintln!("[GUI ERROR {:?}] Conversion failed: {}", block_start.elapsed(), e),
        }
        
        result
    })
    .await
    .map_err(|e| {
        let err_msg = format!("Task join error: {}", e);
        eprintln!("[GUI ERROR {:?}] {}", start_time.elapsed(), err_msg);
        err_msg
    })?
    .map_err(|e| {
        let err_msg = format!("PDF conversion failed: {}", e);
        eprintln!("[GUI ERROR {:?}] {}", start_time.elapsed(), err_msg);
        err_msg
    })?;

    if images.is_empty() {
        eprintln!("[GUI ERROR {:?}] No pages extracted", start_time.elapsed());
        return Err("No pages were extracted from PDF".to_string());
    }

    eprintln!("[GUI {:?}] Converted {} pages, creating CBZ archive...", start_time.elapsed(), images.len());
    
    let zip_start = std::time::Instant::now();
    let window_for_zip = window.clone();
    
    let cbz_data = utils::create_cbz_with_progress(images, move |done, total| {
        // Map zip progress from 90% to 100% (10% range)
        let percentage = 90 + ((done as f32 / total as f32) * 10.0) as u32;
        let _ = window_for_zip.emit("conversion-progress", serde_json::json!({
            "percentage": percentage,
            "message": format!("Archive CBZ {}/{} fichiers...", done, total)
        }));
    })
        .map_err(|e| {
            let err_msg = format!("Failed to create CBZ archive: {}", e);
            eprintln!("[GUI ERROR {:?}] {}", start_time.elapsed(), err_msg);
            err_msg
        })?;
    
    let zip_elapsed = zip_start.elapsed().as_secs_f64();
    eprintln!("[GUI {:?}] CBZ archive created in {:.2}s", start_time.elapsed(), zip_elapsed);

    eprintln!("[GUI {:?}] ========== CONVERSION SUCCESS ==========", start_time.elapsed());
    eprintln!("[GUI {:?}] CBZ created: {} bytes ({:.2} MB)", start_time.elapsed(), cbz_data.len(), cbz_data.len() as f64 / (1024.0 * 1024.0));
    eprintln!("[GUI {:?}] TOTAL TIME: {:?}", start_time.elapsed(), start_time.elapsed());
    
    let _ = window.emit("conversion-progress", serde_json::json!({
        "percentage": 100,
        "message": format!("Terminé! {} MB", cbz_data.len() / 1024 / 1024)
    }));
    
    Ok(cbz_data)
}

/// Convert PDF lossless mode (PNG at same DPI as lossy)
fn convert_pdf_lossless(pdf_data: &[u8], dpi: u32) -> Result<Vec<(String, Vec<u8>)>, String> {
    use pdfium_render::prelude::*;
    use image::ImageEncoder;
    
    let pdfium = crate::utils::bind_pdfium()
        .map_err(|e| format!("Failed to initialize Pdfium: {}", e))?;
    let document = pdfium
        .load_pdf_from_byte_vec(pdf_data.to_vec(), None)
        .map_err(|e| format!("Failed to load PDF: {}", e))?;

    let page_count = document.pages().len();
    if page_count == 0 {
        return Err("PDF has no pages".to_string());
    }

    let mut images = Vec::new();

    for page_num in 1..=page_count as u32 {
        let page = document
            .pages()
            .get((page_num - 1) as u16)
            .map_err(|e| format!("Failed to get page {}: {}", page_num, e))?;

        // Render at same DPI as lossy mode for consistency
        let scale = dpi as f32 / 72.0;
        let width_px = (page.width().value * scale) as i32;
        let height_px = (page.height().value * scale) as i32;

        let config = PdfRenderConfig::new()
            .set_target_width(width_px)
            .set_target_height(height_px);

        let bitmap = page
            .render_with_config(&config)
            .map_err(|e| format!("Failed to render page {}: {}", page_num, e))?;

        let image = bitmap.as_image();
        let rgb_image = image.to_rgb8();
        
        // Encode as PNG (lossless)
        let mut png_data = Vec::new();
        let encoder = image::codecs::png::PngEncoder::new(&mut png_data);
        encoder.write_image(
            rgb_image.as_raw(),
            rgb_image.width(),
            rgb_image.height(),
            image::ExtendedColorType::Rgb8,
        ).map_err(|e| format!("Failed to encode page {}: {}", page_num, e))?;
        
        let filename = format!("page_{:04}.png", page_num);
        images.push((filename, png_data));
    }

    Ok(images)
}

/// Convert PDF with parallel processing (optimized)
fn convert_pdf_with_pdfium_parallel(
    pdf_data: &[u8],
    dpi: u32,
    quality: u8,
    window: tauri::Window,
) -> Result<Vec<(String, Vec<u8>)>, String> {
    use pdfium_render::prelude::*;
    use std::time::Instant;

    let start_time = Instant::now();
    eprintln!("[PARALLEL {:?}] Starting PDF conversion at {} DPI, quality {}", start_time.elapsed(), dpi, quality);

    let pdfium = crate::utils::bind_pdfium()
        .map_err(|e| format!("Failed to initialize Pdfium: {}", e))?;
    let document = pdfium
        .load_pdf_from_byte_vec(pdf_data.to_vec(), None)
        .map_err(|e| format!("Failed to load PDF: {}", e))?;

    let page_count = document.pages().len();
    if page_count == 0 {
        return Err("PDF has no pages".to_string());
    }

    // Calculate DPI scale factor
    let scale = dpi as f64 / 72.0;
    eprintln!("[PARALLEL {:?}] DPI={}, scale factor={:.3}", start_time.elapsed(), dpi, scale);
    eprintln!("[PARALLEL {:?}] Processing {} pages with Direct Extract mode...", start_time.elapsed(), page_count);
    
    let _ = window.emit("conversion-progress", serde_json::json!({
        "percentage": 10,
        "message": format!("Extraction de {} pages...", page_count)
    }));
    
    // Try direct extraction first, fallback to render if needed
    let mut rendered_images = Vec::new();
    for page_num in 1..=page_count as u32 {
        // Progress update every 20 pages
        if page_num % 20 == 0 {
            let progress = 10 + ((page_num as f32 / page_count as f32) * 40.0) as u32;
            let _ = window.emit("conversion-progress", serde_json::json!({
                "percentage": progress,
                "message": format!("Page {}/{}", page_num, page_count)
            }));
        }
        
        let page = document
            .pages()
            .get((page_num - 1) as u16)
            .map_err(|e| format!("Failed to get page {}: {}", page_num, e))?;

        // Get effective page boundaries - try CropBox, fallback to TrimBox, then MediaBox
        let boundaries = page.boundaries();
        
        // Detailed box diagnostics for page 1
        if page_num == 1 {
            eprintln!("[PARALLEL {:?}] Page 1 boxes:", start_time.elapsed());
            
            // MediaBox (always present)
            if let Ok(media_box) = boundaries.media() {
                let b = media_box.bounds;
                let w = b.width().value;
                let h = b.height().value;
                eprintln!("  MediaBox:  left={:.2}, bottom={:.2}, right={:.2}, top={:.2} (w={:.2}, h={:.2})",
                    b.left().value, b.bottom().value, b.right().value, b.top().value, w, h);
            }
            
            // CropBox (if present)
            if let Ok(crop_box) = boundaries.crop() {
                let b = crop_box.bounds;
                let w = b.width().value;
                let h = b.height().value;
                eprintln!("  CropBox:   left={:.2}, bottom={:.2}, right={:.2}, top={:.2} (w={:.2}, h={:.2})",
                    b.left().value, b.bottom().value, b.right().value, b.top().value, w, h);
            } else {
                eprintln!("  CropBox:   not present");
            }
            
            // TrimBox (if present)
            if let Ok(trim_box) = boundaries.trim() {
                let b = trim_box.bounds;
                let w = b.width().value;
                let h = b.height().value;
                eprintln!("  TrimBox:   left={:.2}, bottom={:.2}, right={:.2}, top={:.2} (w={:.2}, h={:.2})",
                    b.left().value, b.bottom().value, b.right().value, b.top().value, w, h);
            } else {
                eprintln!("  TrimBox:   not present");
            }
            
            // Page width/height (MediaBox implicit)
            eprintln!("  page.width/height: {:.2} x {:.2}", page.width().value, page.height().value);
        }
        
        // Try to extract embedded image directly
        let direct_extract_result = try_extract_page_image(&page, page_num, quality);
        
        let image = match direct_extract_result {
            Some(Ok((img, mode))) => {
                if page_num == 1 {
                    eprintln!("[PARALLEL {:?}] Page 1: Direct extract SUCCESS ({})", start_time.elapsed(), mode);
                }
                img
            }
            Some(Err(e)) => {
                if page_num == 1 {
                    eprintln!("[PARALLEL {:?}] Page 1: Direct extract failed ({}), falling back to render", start_time.elapsed(), e);
                }
                // Fallback to render
                render_page_to_image(&page, &boundaries, dpi, scale, page_num == 1, &start_time)?
            }
            None => {
                if page_num == 1 {
                    eprintln!("[PARALLEL {:?}] Page 1: No suitable image found, falling back to render", start_time.elapsed());
                }
                // Fallback to render
                render_page_to_image(&page, &boundaries, dpi, scale, page_num == 1, &start_time)?
            }
        };
        
        rendered_images.push((page_num, image));
    }
    
    let render_elapsed = start_time.elapsed().as_secs_f64();
    eprintln!("[PARALLEL {:?}] Page processing completed in {:.2}s", start_time.elapsed(), render_elapsed);

    eprintln!("[PARALLEL {:?}] Processing done, encoding {} pages in parallel...", start_time.elapsed(), page_count);
    eprintln!("[PARALLEL {:?}] JPEG lossy encoding at quality={}", start_time.elapsed(), quality);
    
    let _ = window.emit("conversion-progress", serde_json::json!({
        "percentage": 50,
        "message": "Extraction terminée, compression en cours..."
    }));
    
    let parallel_start = std::time::Instant::now();
    let encode_counter = Arc::new(AtomicUsize::new(0));
    let last_progress_time = Arc::new(std::sync::Mutex::new(std::time::Instant::now()));
    
    // Process in parallel (encoding only - no more resize!)
    let results: Vec<_> = rendered_images
        .into_par_iter()
        .map(|(page_num, image)| {
            let page_start = std::time::Instant::now();
            
            // Image is already at correct DPI - encode directly as JPEG
            let rgb_image = image.to_rgb8();
            let mut jpeg_data = Vec::new();
            
            let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(
                &mut jpeg_data,
                quality
            );
            
            encoder.encode(
                rgb_image.as_raw(),
                rgb_image.width(),
                rgb_image.height(),
                image::ExtendedColorType::Rgb8,
            ).map_err(|e| format!("Failed to encode page {}: {}", page_num, e))?;

            // Update progress counter and emit events (throttled)
            let encoded = encode_counter.fetch_add(1, Ordering::Relaxed) + 1;
            
            // Emit progress every 5 pages or every 250ms
            let should_emit = (encoded % 5 == 0) || {
                let mut last_time = last_progress_time.lock().unwrap();
                let now = std::time::Instant::now();
                if now.duration_since(*last_time).as_millis() >= 250 {
                    *last_time = now;
                    true
                } else {
                    false
                }
            };
            
            if should_emit {
                // Map encoding progress from 50% to 90% (40% range)
                let percentage = 50 + ((encoded as f32 / page_count as f32) * 40.0) as u32;
                let _ = window.emit("conversion-progress", serde_json::json!({
                    "percentage": percentage,
                    "message": format!("Compression {}/{} pages...", encoded, page_count)
                }));
            }

            if page_num % 50 == 0 {
                eprintln!("[PARALLEL {:?}] Page {}/{} encoded in {:?}", 
                    parallel_start.elapsed(), page_num, page_count, page_start.elapsed());
            }
            
            let filename = format!("page_{:04}.jpg", page_num);
            Ok::<_, String>((page_num, filename, jpeg_data))
        })
        .collect();
    
    let encode_elapsed = parallel_start.elapsed().as_secs_f64();
    eprintln!("[PARALLEL {:?}] Encoding completed in {:.2}s", start_time.elapsed(), encode_elapsed);

    eprintln!("[PARALLEL {:?}] All pages processed, collecting results...", start_time.elapsed());
    
    let _ = window.emit("conversion-progress", serde_json::json!({
        "percentage": 90,
        "message": "Création de l'archive CBZ..."
    }));

    // Collect results
    let mut images = Vec::new();
    for result in results {
        let (_, filename, jpeg_data) = result?;
        images.push((filename, jpeg_data));
    }
    
    // Calculate total size
    let total_size_bytes: usize = images.iter().map(|(_, data)| data.len()).sum();
    let total_size_mb = total_size_bytes as f64 / (1024.0 * 1024.0);

    let elapsed = start_time.elapsed().as_secs_f64();
    eprintln!("[PARALLEL {:?}] Conversion completed in {:.2}s ({:.1} pages/sec)",
        start_time.elapsed(), elapsed, page_count as f64 / elapsed);
    eprintln!("[PARALLEL {:?}] Total JPEG data: {:.2} MB ({} pages)",
        start_time.elapsed(), total_size_mb, page_count);
    eprintln!("[PARALLEL {:?}] Performance breakdown - Render: {:.2}s, Encode: {:.2}s",
        start_time.elapsed(), render_elapsed, encode_elapsed);

    Ok(images)
}

/// Convert PDF to images using pdfium-render (no external dependencies)
fn convert_pdf_with_pdfium(
    pdf_data: &[u8],
    dpi: u32,
) -> Result<Vec<(String, Vec<u8>)>, String> {
    use crate::models::ImageFormat;
    use std::time::Instant;

    let start_time = Instant::now();
    eprintln!("[PERFORMANCE] Starting PDF conversion at {} DPI", dpi);

    let effective_dpi = if dpi == 0 { 300 } else { dpi };

    // Load PDF to get page count
    let load_start = Instant::now();
    let pdfium = crate::utils::bind_pdfium()
        .map_err(|e| format!("Failed to initialize Pdfium: {}", e))?;
    let document = pdfium
        .load_pdf_from_byte_vec(pdf_data.to_vec(), None)
        .map_err(|e| format!("Failed to load PDF: {}", e))?;

    let page_count = document.pages().len();
    eprintln!("[PERFORMANCE] Loaded PDF with {} pages in {:.2}ms",
        page_count,
        load_start.elapsed().as_millis());

    if page_count == 0 {
        return Err("PDF has no pages".to_string());
    }

    eprintln!("[PERFORMANCE] Starting sequential rendering of {} pages", page_count);
    let render_start = Instant::now();

    let mut images = Vec::new();

    // Render pages sequentially (PDFium has issues with parallel rendering)
    for page_num in 1..=page_count as u32 {
        // Log progress every 10 pages
        if page_num % 10 == 1 || page_num == page_count as u32 {
            eprintln!("[PERFORMANCE] Rendering page {}/{}", page_num, page_count);
        }

        let page_start = Instant::now();
        let img_data = utils::render_pdf_page_sync(pdf_data, page_num, effective_dpi, ImageFormat::Png, 95)
            .map_err(|e| format!("Failed to render page {}: {}", page_num, e))?;

        let img_size_kb = img_data.len() as f64 / 1024.0;
        let filename = format!("page_{:04}.png", page_num);
        images.push((filename, img_data));

        // Only log detailed timing every 20 pages to reduce spam
        if page_num % 20 == 0 {
            eprintln!("[PERFORMANCE] Page {} done in {:.2}ms ({:.2} KB)",
                page_num,
                page_start.elapsed().as_millis(),
                img_size_kb);
        }
    }

    eprintln!("[PERFORMANCE] Sequential rendering completed in {:.2}s",
        render_start.elapsed().as_secs_f64());

    let total_size_mb = images.iter().map(|(_, data)| data.len() as f64).sum::<f64>() / (1024.0 * 1024.0);
    eprintln!("[PERFORMANCE] Total conversion time: {:.2}s, Output size: {:.2} MB, Throughput: {:.1} pages/sec",
        start_time.elapsed().as_secs_f64(),
        total_size_mb,
        page_count as f64 / start_time.elapsed().as_secs_f64());

    Ok(images)
}

#[tauri::command]
pub async fn convert_cbz_to_pdf(path: String, lossless: bool, quality: u32) -> Result<Vec<u8>, String> {
    let cbz_path = PathBuf::from(&path);

    if !cbz_path.exists() {
        return Err("CBZ file not found".to_string());
    }

    eprintln!("[GUI] Converting CBZ to PDF: {} (Lossless: {}, Quality: {})", path, lossless, quality);

    let cbz_data = fs::read(&cbz_path)
        .map_err(|e| format!("Failed to read CBZ file: {}", e))?;

    let images = utils::extract_images_from_cbz(&cbz_data)
        .map_err(|e| format!("Failed to extract CBZ: {}", e))?;

    if images.is_empty() {
        return Err("No images found in CBZ file".to_string());
    }

    eprintln!("[GUI] Extracted {} images, creating PDF...", images.len());

    let pdf_data = utils::create_pdf_from_images(images, |_current, _total| {})
        .map_err(|e| format!("Failed to create PDF: {}", e))?;

    eprintln!("[GUI] PDF created: {} bytes", pdf_data.len());

    Ok(pdf_data)
}

#[tauri::command]
pub async fn save_last_pdf(data: Vec<u8>, filename: String) -> Result<String, String> {
    let home_dir = std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .map_err(|_| "Could not determine home directory".to_string())?;

    let downloads_dir = PathBuf::from(home_dir).join("Downloads");
    fs::create_dir_all(&downloads_dir)
        .map_err(|e| format!("Failed to create downloads directory: {}", e))?;

    let file_path = downloads_dir.join(&filename);
    fs::write(&file_path, data)
        .map_err(|e| format!("Failed to save PDF: {}", e))?;

    Ok(file_path.to_string_lossy().to_string())
}

#[tauri::command]
pub async fn open_file_with_default_app(path: String) -> Result<(), String> {
    #[cfg(target_os = "macos")]
    {
        use std::process::Command;
        Command::new("open")
            .arg(&path)
            .spawn()
            .map_err(|e| format!("Failed to open file: {}", e))?;
    }

    #[cfg(target_os = "windows")]
    {
        use std::process::Command;
        Command::new("cmd")
            .args(&["/C", "start", "", &path])
            .spawn()
            .map_err(|e| format!("Failed to open file: {}", e))?;
    }

    #[cfg(target_os = "linux")]
    {
        use std::process::Command;
        Command::new("xdg-open")
            .arg(&path)
            .spawn()
            .map_err(|e| format!("Failed to open file: {}", e))?;
    }

    Ok(())
}

/// Try to extract the largest embedded image from a PDF page
/// Returns Some(Ok((image, mode))) if successful, Some(Err) if extraction failed, None if no suitable image
fn try_extract_page_image(
    page: &pdfium_render::prelude::PdfPage,
    page_num: u32,
    _quality: u8,
) -> Option<Result<(image::DynamicImage, &'static str), String>> {
    use pdfium_render::prelude::*;
    
    // Find all image objects on the page
    let objects = page.objects();
    let mut best_image: Option<usize> = None;
    let mut best_area = 0.0f32;
    
    // Get page dimensions for coverage check
    let page_width = page.width().value;
    let page_height = page.height().value;
    let page_area = page_width * page_height;
    
    for (idx, object) in objects.iter().enumerate() {
        if let Some(img_obj) = object.as_image_object() {
            if let Ok(bounds) = object.bounds() {
                let img_width = bounds.width().value;
                let img_height = bounds.height().value;
                let img_area = img_width * img_height;
                
                if page_num == 1 {
                    eprintln!("[DIRECT] Page 1: Image object {} - {:.1}x{:.1} pt, area={:.1} pt^2 ",
                        idx, img_width, img_height, img_area);
                }
                
                // Pick the largest image
                if img_area > best_area {
                    best_area = img_area;
                    best_image = Some(idx);
                }
            }
        }
    }
    
    // If we found an image covering > 80% of page, try to extract it
    if let Some(idx) = best_image {
        let coverage = (best_area / page_area) * 100.0;
        
        if page_num == 1 {
            eprintln!("[DIRECT] Page 1: Best image covers {:.1}% of page ", coverage);
        }
        
        if coverage > 80.0 {
            // Try to extract the image
            if let Ok(obj) = objects.get(idx) {
                if let Some(img_obj) = obj.as_image_object() {
                    if page_num == 1 {
                        eprintln!("[DIRECT] Page 1: Attempting raw image extraction...");
                    }
                    
                    // Try get_raw_image() method - returns Result<DynamicImage>
                    if let Ok(dynamic_img) = img_obj.get_raw_image() {
                        if page_num == 1 {
                            eprintln!("[DIRECT] Page 1: Successfully extracted raw image {}x{}",
                                dynamic_img.width(), dynamic_img.height());
                        }
                        return Some(Ok((dynamic_img, "DirectExtract")));
                    } else if page_num == 1 {
                        eprintln!("[DIRECT] Page 1: Raw extraction failed");
                    }
                }
            }
        } else if page_num == 1 {
            eprintln!("[DIRECT] Page 1: Coverage too low ({:.1}%), falling back to render ", coverage);
        }
    }
    
    None
}

/// Render a page to image using the CropBox/TrimBox aware method
fn render_page_to_image(
    page: &pdfium_render::prelude::PdfPage,
    boundaries: &pdfium_render::prelude::PdfPageBoundaries,
    dpi: u32,
    scale: f64,
    is_first_page: bool,
    start_time: &std::time::Instant,
) -> Result<image::DynamicImage, String> {
    use pdfium_render::prelude::*;
    
    let (use_box, width_pt, height_pt) = if let Ok(crop_box) = boundaries.crop() {
        ("CropBox", crop_box.bounds.width().value as f64, crop_box.bounds.height().value as f64)
    } else if let Ok(trim_box) = boundaries.trim() {
        ("TrimBox", trim_box.bounds.width().value as f64, trim_box.bounds.height().value as f64)
    } else {
        ("MediaBox (fallback)", page.width().value as f64, page.height().value as f64)
    };
    
    if is_first_page {
        eprintln!("[PARALLEL {:?}] Page 1 render config:", start_time.elapsed());
        eprintln!("  Using box: {} ({:.1}x{:.1} pt)", use_box, width_pt, height_pt);
        eprintln!("  DPI: {}, scale: {:.3}", dpi, scale);
    }

    // Calculate pixel dimensions at target DPI
    let target_width_px = (width_pt * scale).round() as i32;
    let target_height_px = (height_pt * scale).round() as i32;
    
    // Enforce minimum dimensions
    let target_width_px = target_width_px.max(1);
    let target_height_px = target_height_px.max(1);

    if is_first_page {
        eprintln!("  Target size: {}x{} px", target_width_px, target_height_px);
    }

    let config = PdfRenderConfig::new()
        .set_target_width(target_width_px)
        .set_target_height(target_height_px);

    let bitmap = page
        .render_with_config(&config)
        .map_err(|e| format!("Failed to render page: {}", e))?;

    Ok(bitmap.as_image().clone())
}

#[tauri::command]
pub async fn get_file_size(path: String) -> Result<u64, String> {
    let file_path = PathBuf::from(&path);
    fs::metadata(&file_path)
        .map(|m| m.len())
        .map_err(|e| format!("Failed to get file size: {}", e))
}

#[tauri::command]
pub fn cancel_conversion() -> Result<(), String> {
    Ok(())
}

