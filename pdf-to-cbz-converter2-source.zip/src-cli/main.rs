use anyhow::{Context, Result};
use clap::{Parser, Subcommand};
use std::path::PathBuf;

mod archive;
mod image;
mod pdf;

#[derive(Parser)]
#[command(
    name = "pdf-to-cbz",
    version = "3.0.0",
    about = "Ultra-fast PDF ↔ CBZ/CBR converter",
    long_about = "Convert PDF files to CBZ/CBR comic archives and vice versa. Supports batch operations and custom DPI settings."
)]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Convert PDF to CBZ
    #[command(about = "Convert PDF file(s) to CBZ archive")]
    PdfToCbz {
        /// Input PDF file path
        #[arg(value_name = "INPUT")]
        input: PathBuf,

        /// Output CBZ file path (optional, auto-generated from input if not provided)
        #[arg(short, long, value_name = "OUTPUT")]
        output: Option<PathBuf>,

        /// DPI for rendering (default: 300, ignored if --lossless is used)
        #[arg(short, long, default_value = "300")]
        dpi: u32,

        /// Extract original images without re-rendering (lossless mode)
        #[arg(short, long)]
        lossless: bool,

        /// JPEG quality for compression (1-100, default: 90, only for rendered images)
        #[arg(short = 'q', long, default_value = "90")]
        quality: u8,

        /// Number of threads for parallel processing (default: number of CPU cores)
        #[arg(short = 't', long)]
        threads: Option<usize>,
    },

    /// Convert CBZ/CBR to PDF
    #[command(about = "Convert CBZ or CBR archive to PDF")]
    CbzToPdf {
        /// Input CBZ/CBR file path
        #[arg(value_name = "INPUT")]
        input: PathBuf,

        /// Output PDF file path (optional, auto-generated from input if not provided)
        #[arg(short, long, value_name = "OUTPUT")]
        output: Option<PathBuf>,

        /// Preserve original image format and quality (lossless mode)
        #[arg(short, long)]
        lossless: bool,

        /// JPEG quality for re-compression (1-100, default: 90, only if not lossless)
        #[arg(short = 'q', long, default_value = "90")]
        quality: u8,
    },

    /// Self-check: diagnose PDF page 1 rendering
    #[command(about = "Extract and analyze page 1 from PDF for diagnostics")]
    SelfCheck {
        /// Input PDF file path
        #[arg(value_name = "INPUT")]
        input: PathBuf,

        /// DPI for rendering (default: 200)
        #[arg(short, long, default_value = "200")]
        dpi: u32,

        /// Output debug image file (default: _debug_page1.png)
        #[arg(short, long, default_value = "_debug_page1.png")]
        output: PathBuf,
        
        /// Fail if white_ratio > threshold (default: 0.90)
        #[arg(long, default_value = "0.90")]
        max_white_ratio: f64,
    },
}

fn main() -> Result<()> {
    let cli = Cli::parse();

    match cli.command {
        Commands::PdfToCbz {
            input,
            output,
            dpi,
            lossless,
            quality,
            threads,
        } => convert_pdf_to_cbz(&input, output, dpi, lossless, quality, threads),
        Commands::CbzToPdf { input, output, lossless, quality } => convert_cbz_to_pdf(&input, output, lossless, quality),
        Commands::SelfCheck { input, dpi, output, max_white_ratio } => self_check(&input, dpi, &output, max_white_ratio),
    }
}

fn convert_pdf_to_cbz(input_path: &PathBuf, output_path: Option<PathBuf>, dpi: u32, lossless: bool, quality: u8, threads: Option<usize>) -> Result<()> {
    // Validate input
    if !input_path.exists() {
        anyhow::bail!("Input PDF file not found: {:?}", input_path);
    }

    if !input_path.is_file() {
        anyhow::bail!("Input path is not a file: {:?}", input_path);
    }

    // Validate quality
    if quality == 0 || quality > 100 {
        anyhow::bail!("Quality must be between 1 and 100");
    }

    // Configure thread pool
    if let Some(num_threads) = threads {
        rayon::ThreadPoolBuilder::new()
            .num_threads(num_threads)
            .build_global()
            .context("Failed to configure thread pool")?;
        println!("Using {} threads for parallel processing", num_threads);
    } else {
        println!("Using {} threads (auto-detected)", rayon::current_num_threads());
    }

    // Determine output path
    let output_file = match output_path {
        Some(p) => p,
        None => {
            let stem = input_path.file_stem().context("Invalid input filename")?;
            input_path.with_file_name(format!("{}.cbz", stem.to_string_lossy()))
        }
    };

    println!("Converting PDF to CBZ: {:?}", input_path);
    println!("Output: {:?}", output_file);
    
    if lossless {
        println!("Mode: Lossless (extracting original images)");
    } else {
        println!("Mode: Rendering at {} DPI, JPEG quality: {}", dpi, quality);
    }

    // Read PDF
    let pdf_data = std::fs::read(&input_path)
        .context("Failed to read PDF file")?;

    // Convert to images
    let images = if lossless {
        pdf::extract_images_lossless(&pdf_data)
            .context("Failed to extract images from PDF")?
    } else {
        pdf::convert_pdf_to_images_parallel(&pdf_data, dpi, quality)
            .context("Failed to convert PDF to images")?
    };

    println!("Processed {} pages", images.len());

    // Create CBZ archive
    let cbz_data = archive::create_cbz(images)
        .context("Failed to create CBZ archive")?;

    // Write output
    std::fs::write(&output_file, cbz_data)
        .context("Failed to write CBZ file")?;

    let file_size_mb = std::fs::metadata(&output_file)
        .map(|m| m.len() as f64 / (1024.0 * 1024.0))
        .unwrap_or(0.0);

    println!("✓ Successfully created: {:?} ({:.2} MB)", output_file, file_size_mb);
    Ok(())
}

fn convert_cbz_to_pdf(input_path: &PathBuf, output_path: Option<PathBuf>, lossless: bool, quality: u8) -> Result<()> {
    // Validate input
    if !input_path.exists() {
        anyhow::bail!("Input CBZ/CBR file not found: {:?}", input_path);
    }

    if !input_path.is_file() {
        anyhow::bail!("Input path is not a file: {:?}", input_path);
    }

    // Validate quality
    if quality == 0 || quality > 100 {
        anyhow::bail!("Quality must be between 1 and 100");
    }

    // Determine output path
    let output_file = match output_path {
        Some(p) => p,
        None => {
            let stem = input_path.file_stem().context("Invalid input filename")?;
            input_path.with_file_name(format!("{}.pdf", stem.to_string_lossy()))
        }
    };

    println!("Converting CBZ/CBR to PDF: {:?}", input_path);
    println!("Output: {:?}", output_file);
    
    if lossless {
        println!("Mode: Lossless (preserving original image quality)");
    } else {
        println!("Mode: Re-compressing with JPEG quality: {}", quality);
    }

    // Read archive
    let archive_data = std::fs::read(&input_path)
        .context("Failed to read CBZ/CBR file")?;

    // Extract images
    let images = archive::extract_images(&archive_data)
        .context("Failed to extract images from archive")?;

    if images.is_empty() {
        anyhow::bail!("No images found in archive");
    }

    println!("Extracted {} images", images.len());

    // Create PDF
    let pdf_data = pdf::create_pdf_from_images(images)
        .context("Failed to create PDF from images")?;

    // Write output
    std::fs::write(&output_file, pdf_data)
        .context("Failed to write PDF file")?;

    let file_size_mb = std::fs::metadata(&output_file)
        .map(|m| m.len() as f64 / (1024.0 * 1024.0))
        .unwrap_or(0.0);

    println!("✓ Successfully created: {:?} ({:.2} MB)", output_file, file_size_mb);
    Ok(())
}

fn self_check(input_path: &PathBuf, dpi: u32, output_path: &PathBuf, max_white_ratio: f64) -> Result<()> {
    use pdfium_render::prelude::*;
    
    // Validate input
    if !input_path.exists() {
        anyhow::bail!("Input PDF file not found: {:?}", input_path);
    }

    if !input_path.is_file() {
        anyhow::bail!("Input path is not a file: {:?}", input_path);
    }

    println!("═══════════════════════════════════════════════════════════");
    println!("PDF SELF-CHECK DIAGNOSTIC (SMOKE TEST)");
    println!("═══════════════════════════════════════════════════════════");
    println!("Input:  {:?}", input_path);
    println!("Output: {:?}", output_path);
    println!("DPI:    {}", dpi);
    println!("Max white ratio: {:.1}%", max_white_ratio * 100.0);
    println!();

    // Read PDF
    let pdf_data = std::fs::read(&input_path)
        .context("Failed to read PDF file")?;

    let pdfium = Pdfium::default();
    let document = pdfium
        .load_pdf_from_byte_vec(pdf_data, None)
        .context("Failed to load PDF")?;

    let page_count = document.pages().len();
    println!("Total pages: {}", page_count);
    
    if page_count == 0 {
        anyhow::bail!("PDF has no pages");
    }

    // Get page 1
    let page = document
        .pages()
        .get(0)
        .context("Failed to get page 1")?;

    let boundaries = page.boundaries();
    
    println!();
    println!("───────────────────────────────────────────────────────────");
    println!("PAGE 1 BOX ANALYSIS");
    println!("───────────────────────────────────────────────────────────");
    
    // MediaBox (always present)
    if let Ok(media_box) = boundaries.media() {
        let b = media_box.bounds;
        let w = b.width().value;
        let h = b.height().value;
        println!("MediaBox:");
        println!("  left={:.2}, bottom={:.2}, right={:.2}, top={:.2}", 
            b.left().value, b.bottom().value, b.right().value, b.top().value);
        println!("  width={:.2} pt, height={:.2} pt", w, h);
    }
    
    // CropBox
    let has_crop = if let Ok(crop_box) = boundaries.crop() {
        let b = crop_box.bounds;
        let w = b.width().value;
        let h = b.height().value;
        println!("CropBox:");
        println!("  left={:.2}, bottom={:.2}, right={:.2}, top={:.2}", 
            b.left().value, b.bottom().value, b.right().value, b.top().value);
        println!("  width={:.2} pt, height={:.2} pt", w, h);
        true
    } else {
        println!("CropBox: NOT PRESENT");
        false
    };
    
    // TrimBox
    let has_trim = if let Ok(trim_box) = boundaries.trim() {
        let b = trim_box.bounds;
        let w = b.width().value;
        let h = b.height().value;
        println!("TrimBox:");
        println!("  left={:.2}, bottom={:.2}, right={:.2}, top={:.2}", 
            b.left().value, b.bottom().value, b.right().value, b.top().value);
        println!("  width={:.2} pt, height={:.2} pt", w, h);
        true
    } else {
        println!("TrimBox: NOT PRESENT");
        false
    };

    println!();
    println!("page.width/height: {:.2} x {:.2} pt", page.width().value, page.height().value);

    // Check for image objects (Direct Extract pipeline)
    println!();
    println!("───────────────────────────────────────────────────────────");
    println!("IMAGE OBJECT DETECTION");
    println!("───────────────────────────────────────────────────────────");
    
    let objects = page.objects();
    let mut image_count = 0;
    let mut content_bbox: Option<(f32, f32, f32, f32)> = None;
    
    for (idx, object) in objects.iter().enumerate() {
        // Track all objects for content bbox
        if let Ok(obj_bbox) = object.bounds() {
            let obj_rect = (
                obj_bbox.left().value,
                obj_bbox.bottom().value,
                obj_bbox.right().value,
                obj_bbox.top().value
            );
            
            if let Some((min_x, min_y, max_x, max_y)) = content_bbox {
                content_bbox = Some((
                    min_x.min(obj_rect.0),
                    min_y.min(obj_rect.1),
                    max_x.max(obj_rect.2),
                    max_y.max(obj_rect.3)
                ));
            } else {
                content_bbox = Some(obj_rect);
            }
        }
        
        if let Some(_) = object.as_image_object() {
            image_count += 1;
            println!("Image object found at index {}", idx);
        }
    }
    
    // Display content bounding box
    println!();
    if let Some((min_x, min_y, max_x, max_y)) = content_bbox {
        let content_w = max_x - min_x;
        let content_h = max_y - min_y;
        println!("Content Bounding Box (union of all objects):");
        println!("  left={:.2}, bottom={:.2}, right={:.2}, top={:.2}",
            min_x, min_y, max_x, max_y);
        println!("  width={:.2} pt, height={:.2} pt", content_w, content_h);
        
        // Compare to page size
        let page_w = page.width().value;
        let page_h = page.height().value;
        let content_ratio = ((content_w * content_h) / (page_w * page_h)) * 100.0;
        println!("  coverage={:.1}% of page area", content_ratio);
        
        if content_ratio < 25.0 {
            println!("  ⚠️  WARNING: Content covers < 25% of page - may indicate offset/tiny thumbnail issue");
        }
    } else {
        println!("Content Bounding Box: NO OBJECTS FOUND");
    }
    
    let pipeline = if image_count > 0 {
        println!("Total image objects: {}", image_count);
        println!("Pipeline: Direct Extract (would attempt image extraction)");
        "Direct Extract (fallback to render)"
    } else {
        println!("No image objects found");
        println!("Pipeline: Render");
        "Render"
    };

    // Render page 1
    println!();
    println!("───────────────────────────────────────────────────────────");
    println!("RENDERING PAGE 1");
    println!("───────────────────────────────────────────────────────────");
    
    let scale = dpi as f64 / 72.0;
    
    let (use_box, width_pt, height_pt) = if has_crop {
        let crop_box = boundaries.crop().unwrap();
        ("CropBox", crop_box.bounds.width().value as f64, crop_box.bounds.height().value as f64)
    } else if has_trim {
        let trim_box = boundaries.trim().unwrap();
        ("TrimBox", trim_box.bounds.width().value as f64, trim_box.bounds.height().value as f64)
    } else {
        ("MediaBox", page.width().value as f64, page.height().value as f64)
    };
    
    println!("Using box: {}", use_box);
    println!("Box dimensions: {:.2} x {:.2} pt", width_pt, height_pt);
    println!("Scale factor: {:.3} (DPI {} / 72)", scale, dpi);
    
    let target_width_px = (width_pt * scale).round() as i32;
    let target_height_px = (height_pt * scale).round() as i32;
    
    println!("Target size: {} x {} px", target_width_px, target_height_px);

    let config = PdfRenderConfig::new()
        .set_target_width(target_width_px.max(1))
        .set_target_height(target_height_px.max(1));

    let bitmap = page
        .render_with_config(&config)
        .context("Failed to render page 1")?;

    let img = bitmap.as_image();
    
    println!("Rendered image: {} x {} px", img.width(), img.height());

    // Compute non-white pixel percentage
    println!();
    println!("───────────────────────────────────────────────────────────");
    println!("SANITY CHECK");
    println!("───────────────────────────────────────────────────────────");
    
    // Use external image crate, not our local module
    let thumbnail = ::image::imageops::resize(&img, 64, 64, ::image::imageops::FilterType::Lanczos3);
    let mut non_white_pixels = 0;
    let total_pixels = 64 * 64;
    
    for pixel in thumbnail.pixels() {
        let ::image::Rgba([r, g, b, _a]) = pixel;
        // Consider pixel non-white if any channel < 250
        if *r < 250 || *g < 250 || *b < 250 {
            non_white_pixels += 1;
        }
    }
    
    let non_white_pct = (non_white_pixels as f64 / total_pixels as f64) * 100.0;
    let white_ratio = 1.0 - (non_white_pct / 100.0);
    
    println!("Non-white pixels (64x64 thumbnail): {}/{} ({:.1}%)", 
        non_white_pixels, total_pixels, non_white_pct);
    println!("White ratio: {:.3} (threshold: {:.3})", white_ratio, max_white_ratio);
    
    let test_passed = white_ratio <= max_white_ratio;
    
    if !test_passed {
        println!("❌ FAILED: White ratio {:.3} exceeds threshold {:.3}!", white_ratio, max_white_ratio);
        println!("   This may indicate a blank page or thumbnail rendering issue.");
    } else if non_white_pct < 1.0 {
        println!("⚠️  WARNING: Less than 1% non-white content detected!");
        println!("   Page may be mostly blank but passes smoke test.");
    } else {
        println!("✓  Non-white content percentage looks healthy");
    }

    // Save debug image
    println!();
    println!("───────────────────────────────────────────────────────────");
    println!("SAVING DEBUG IMAGE");
    println!("───────────────────────────────────────────────────────────");
    
    img.save(output_path)
        .context("Failed to save debug image")?;
    
    let file_size_kb = std::fs::metadata(output_path)
        .map(|m| m.len() as f64 / 1024.0)
        .unwrap_or(0.0);

    println!("Saved: {:?} ({:.1} KB)", output_path, file_size_kb);
    
    // Summary
    println!();
    println!("═══════════════════════════════════════════════════════════");
    println!("SUMMARY");
    println!("═══════════════════════════════════════════════════════════");
    println!("Pipeline:        {}", pipeline);
    println!("Box used:        {}", use_box);
    println!("Rendered size:   {} x {} px", img.width(), img.height());
    println!("File size:       {:.1} KB", file_size_kb);
    println!("Non-white:       {:.1}%", non_white_pct);
    println!("White ratio:     {:.3}", white_ratio);
    
    if test_passed {
        println!("Status:          ✓ PASS");
    } else {
        println!("Status:          ❌ FAIL (white_ratio > {:.3})", max_white_ratio);
    }
    println!("═══════════════════════════════════════════════════════════");

    if !test_passed {
        anyhow::bail!("Smoke test FAILED: white_ratio {:.3} > {:.3}", white_ratio, max_white_ratio);
    }

    Ok(())
}
