use anyhow::{Context, Result};
use pdfium_render::prelude::*;
use image::GenericImageView;
use std::io::Cursor;
use rayon::prelude::*;
use std::sync::{Arc, Mutex};

/// Extract original images from PDF (lossless mode)
/// Optimized: renders full page at native resolution if no extractable images
pub fn extract_images_lossless(pdf_data: &[u8]) -> Result<Vec<(String, Vec<u8>)>> {
    let pdfium = Pdfium::default();
    let document = pdfium
        .load_pdf_from_byte_vec(pdf_data.to_vec(), None)
        .context("Failed to load PDF")?;

    let page_count = document.pages().len();
    if page_count == 0 {
        anyhow::bail!("PDF has no pages");
    }

    let mut images = Vec::new();

    // Process each page
    for page_num in 1..=page_count as u32 {
        let page = document
            .pages()
            .get((page_num - 1) as u16)
            .context(format!("Failed to get page {}", page_num))?;

        let mut page_has_images = false;

        // Try to extract embedded images first
        for (idx, object) in page.objects().iter().enumerate() {
            if let Some(image_object) = object.as_image_object() {
                // Try to get the raw image data
                if let Ok(bitmap) = image_object.get_raw_bitmap() {
                    // Convert bitmap to image
                    let dynamic_image = bitmap.as_image();
                    
                    // Encode as high-quality JPEG (95)
                    let rgb_image = dynamic_image.to_rgb8();
                    let mut jpeg_data = Vec::new();
                    let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(&mut jpeg_data, 95);
                    encoder.encode(
                        rgb_image.as_raw(),
                        rgb_image.width(),
                        rgb_image.height(),
                        image::ExtendedColorType::Rgb8,
                    ).context("Failed to encode extracted image as JPEG")?;
                    
                    let filename = format!("page_{:04}_img_{:02}.jpg", page_num, idx + 1);
                    images.push((filename, jpeg_data));
                    page_has_images = true;
                }
            }
        }

        // If no images were extracted, render the entire page at native resolution
        if !page_has_images {
            // Render at 72 DPI (native PDF resolution) for true lossless
            let width_pt = page.width().value as i32;
            let height_pt = page.height().value as i32;

            let config = PdfRenderConfig::new()
                .set_target_width(width_pt)
                .set_target_height(height_pt);

            let bitmap = page
                .render_with_config(&config)
                .context(format!("Failed to render page {}", page_num))?;

            let image = bitmap.as_image();
            
            // Encode as high-quality JPEG
            let rgb_image = image.to_rgb8();
            let mut jpeg_data = Vec::new();
            let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(&mut jpeg_data, 95);
            encoder.encode(
                rgb_image.as_raw(),
                rgb_image.width(),
                rgb_image.height(),
                image::ExtendedColorType::Rgb8,
            ).context("Failed to encode rendered page as JPEG")?;
            
            let filename = format!("page_{:04}.jpg", page_num);
            images.push((filename, jpeg_data));
        }
    }

    if images.is_empty() {
        anyhow::bail!("No images could be extracted from PDF");
    }

    Ok(images)
}

/// Convert PDF bytes to images at specified DPI with quality control
pub fn convert_pdf_to_images(pdf_data: &[u8], dpi: u32, quality: u8) -> Result<Vec<(String, Vec<u8>)>> {
    let effective_dpi = if dpi == 0 { 300 } else { dpi };

    let pdfium = Pdfium::default();
    let document = pdfium
        .load_pdf_from_byte_vec(pdf_data.to_vec(), None)
        .context("Failed to load PDF")?;

    let page_count = document.pages().len();
    if page_count == 0 {
        anyhow::bail!("PDF has no pages");
    }

    let mut images = Vec::new();

    // Render each page sequentially
    for page_num in 1..=page_count as u32 {
        let page = document
            .pages()
            .get((page_num - 1) as u16)
            .context(format!("Failed to get page {}", page_num))?;

        // Get page dimensions
        let width_pt = page.width().value as f64;
        let height_pt = page.height().value as f64;

        // Render at native 72 DPI first
        let native_width_px = width_pt.round() as i32;
        let native_height_px = height_pt.round() as i32;

        let config = PdfRenderConfig::new()
            .set_target_width(native_width_px)
            .set_target_height(native_height_px);

        let bitmap = page
            .render_with_config(&config)
            .context(format!("Failed to render page {}", page_num))?;

        let mut image = bitmap.as_image().clone();

        // Scale to target DPI if needed
        if effective_dpi != 72 {
            let scale = effective_dpi as f64 / 72.0;
            let width_px = (width_pt * scale).round() as u32;
            let height_px = (height_pt * scale).round() as u32;

            image = image::DynamicImage::ImageRgba8(image::imageops::resize(
                &image,
                width_px,
                height_px,
                image::imageops::FilterType::Lanczos3,
            ));
        }

        // Encode as JPEG with specified quality
        let rgb_image = image.to_rgb8();
        let mut jpeg_data = Vec::new();
        
        let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(
            &mut jpeg_data,
            quality
        );
        
        encoder
            .encode(
                rgb_image.as_raw(),
                rgb_image.width(),
                rgb_image.height(),
                image::ExtendedColorType::Rgb8,
            )
            .context(format!("Failed to encode page {} as JPEG", page_num))?;

        let filename = format!("page_{:04}.jpg", page_num);
        images.push((filename, jpeg_data));
    }

    Ok(images)
}

/// Convert PDF bytes to images at specified DPI with quality control (PARALLEL VERSION)
pub fn convert_pdf_to_images_parallel(pdf_data: &[u8], dpi: u32, quality: u8) -> Result<Vec<(String, Vec<u8>)>> {
    let effective_dpi = if dpi == 0 { 300 } else { dpi };

    let pdfium = Pdfium::default();
    let document = pdfium
        .load_pdf_from_byte_vec(pdf_data.to_vec(), None)
        .context("Failed to load PDF")?;

    let page_count = document.pages().len();
    if page_count == 0 {
        anyhow::bail!("PDF has no pages");
    }

    // Render all pages first (pdfium operations must be sequential)
    let mut rendered_images = Vec::new();
    for page_num in 1..=page_count as u32 {
        let page = document
            .pages()
            .get((page_num - 1) as u16)
            .context(format!("Failed to get page {}", page_num))?;

        // Get page dimensions
        let width_pt = page.width().value as f64;
        let height_pt = page.height().value as f64;

        // Render at native 72 DPI first
        let native_width_px = width_pt.round() as i32;
        let native_height_px = height_pt.round() as i32;

        let config = PdfRenderConfig::new()
            .set_target_width(native_width_px)
            .set_target_height(native_height_px);

        let bitmap = page
            .render_with_config(&config)
            .context(format!("Failed to render page {}", page_num))?;

        let image = bitmap.as_image().clone();
        rendered_images.push((page_num, width_pt, height_pt, image));
    }

    // Now process rendered images in parallel (scaling + encoding)
    let results: Vec<_> = rendered_images
        .into_par_iter()
        .map(|(page_num, width_pt, height_pt, mut image)| {
            // Scale to target DPI if needed
            if effective_dpi != 72 {
                let scale = effective_dpi as f64 / 72.0;
                let width_px = (width_pt * scale).round() as u32;
                let height_px = (height_pt * scale).round() as u32;

                image = image::DynamicImage::ImageRgba8(image::imageops::resize(
                    &image,
                    width_px,
                    height_px,
                    image::imageops::FilterType::Lanczos3,
                ));
            }

            // Encode as JPEG with specified quality
            let rgb_image = image.to_rgb8();
            let mut jpeg_data = Vec::new();
            
            let mut encoder = image::codecs::jpeg::JpegEncoder::new_with_quality(
                &mut jpeg_data,
                quality
            );
            
            encoder
                .encode(
                    rgb_image.as_raw(),
                    rgb_image.width(),
                    rgb_image.height(),
                    image::ExtendedColorType::Rgb8,
                )
                .context(format!("Failed to encode page {} as JPEG", page_num))?;

            let filename = format!("page_{:04}.jpg", page_num);
            Ok::<_, anyhow::Error>((page_num, filename, jpeg_data))
        })
        .collect();

    // Convert results to images, maintaining page order
    let mut images = Vec::new();
    for result in results {
        let (_, filename, jpeg_data) = result?;
        images.push((filename, jpeg_data));
    }

    Ok(images)
}

/// Create PDF from image bytes
pub fn create_pdf_from_images(images: Vec<(String, Vec<u8>)>) -> Result<Vec<u8>> {
    use printpdf::{Mm, PdfDocument};

    if images.is_empty() {
        anyhow::bail!("No images to convert");
    }

    let (document, page1, layer1) =
        PdfDocument::new("CBZ to PDF", Mm(210.0), Mm(297.0), "Layer 1");

    // Add first image
    if let Some((_, image_data)) = images.first() {
        add_image_to_page(&document, page1, layer1, image_data)?;
    }

    // Add remaining images
    for (_, image_data) in images.iter().skip(1) {
        let (page, layer) = document.add_page(Mm(210.0), Mm(297.0), "Page");
        add_image_to_page(&document, page, layer, image_data)?;
    }

    // Serialize to bytes
    let pdf_bytes = document
        .save_to_bytes()
        .map_err(|e| anyhow::anyhow!("Failed to serialize PDF: {:?}", e))?;

    Ok(pdf_bytes)
}

/// Add image to PDF page (A4: 210×297mm)
fn add_image_to_page(
    document: &printpdf::PdfDocumentReference,
    page_id: printpdf::PdfPageIndex,
    layer_id: printpdf::PdfLayerIndex,
    image_data: &[u8],
) -> Result<()> {
    use image::ImageFormat;
    use printpdf::{Image, ImageTransform, Mm};

    // Fast dimension reading
    let (img_width, img_height) = if let Ok(size) = imagesize::blob_size(image_data) {
        (size.width as u32, size.height as u32)
    } else {
        // Fallback: decode image to get dimensions
        let reader = image::ImageReader::new(Cursor::new(image_data));
        let reader_with_format = reader.with_guessed_format()
            .context("Failed to detect image format")?;
        let img = reader_with_format.decode()
            .context("Failed to decode image")?;
        img.dimensions()
    };

    // Get layer
    let layer = document.get_page(page_id).get_layer(layer_id);

    // Try direct JPEG insertion (no decode)
    if let Ok(size) = imagesize::blob_size(image_data) {
        let reader = image::ImageReader::new(Cursor::new(image_data));
        if let Ok(reader_with_format) = reader.with_guessed_format() {
            if matches!(reader_with_format.format(), Some(ImageFormat::Jpeg)) {
                // Direct JPEG insertion (fast!)
                let image_xobject = printpdf::ImageXObject {
                    width: printpdf::Px(size.width),
                    height: printpdf::Px(size.height),
                    color_space: printpdf::ColorSpace::Rgb,
                    bits_per_component: printpdf::ColorBits::Bit8,
                    image_data: image_data.to_vec(),
                    image_filter: Some(printpdf::ImageFilter::DCT),
                    interpolate: true,
                    smask: None,
                    clipping_bbox: None,
                };

                let image = Image::from(image_xobject);
                let dpi = calculate_dpi(size.width as f32, size.height as f32);

                let transform = ImageTransform {
                    translate_x: Some(Mm(0.0)),
                    translate_y: Some(Mm(0.0)),
                    dpi: Some(dpi),
                    rotate: None,
                    ..Default::default()
                };

                image.add_to_layer(layer, transform);
                return Ok(());
            }
        }
    }

    // Fallback: decode and convert
    let reader = image::ImageReader::new(Cursor::new(image_data));
    let reader_with_format = reader
        .with_guessed_format()
        .context("Failed to detect image format")?;
    let img = reader_with_format
        .decode()
        .context("Failed to decode image")?;

    let rgb_img = img.to_rgb8();
    let image_xobject = printpdf::ImageXObject {
        width: printpdf::Px(img_width as usize),
        height: printpdf::Px(img_height as usize),
        color_space: printpdf::ColorSpace::Rgb,
        bits_per_component: printpdf::ColorBits::Bit8,
        image_data: rgb_img.to_vec(),
        image_filter: None,
        interpolate: true,
        smask: None,
        clipping_bbox: None,
    };

    let image = Image::from(image_xobject);
    let dpi = calculate_dpi(img_width as f32, img_height as f32);

    let transform = ImageTransform {
        translate_x: Some(Mm(0.0)),
        translate_y: Some(Mm(0.0)),
        dpi: Some(dpi),
        rotate: None,
        ..Default::default()
    };

    image.add_to_layer(layer, transform);
    Ok(())
}

/// Calculate optimal DPI to fit image on A4 page (210×297mm)
fn calculate_dpi(img_width: f32, img_height: f32) -> f32 {
    // A4 dimensions: 210mm × 297mm = 8.27" × 11.69"
    let page_width_inch = 210.0 / 25.4;
    let page_height_inch = 297.0 / 25.4;

    let dpi_w = img_width / page_width_inch;
    let dpi_h = img_height / page_height_inch;

    dpi_w.max(dpi_h)
}
