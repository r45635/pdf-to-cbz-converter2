import Home from './pages/page';

function App() {
  return (
    <div className="min-h-screen">
      <Home />
    </div>
  );
}

export default App;
